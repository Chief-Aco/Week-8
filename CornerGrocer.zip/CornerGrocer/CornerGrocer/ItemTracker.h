#pragma once
#ifndef ITEMTRACKER_H
#define ITEMTRACKER_H

#include <map>
#include <string>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;

public:
    void loadItems(const std::string& filename);
    int getItemFrequency(const std::string& item);
    void printAllItems();
    void printHistogram();
    void saveFrequencyData(const std::string& filename);
};

#endif
