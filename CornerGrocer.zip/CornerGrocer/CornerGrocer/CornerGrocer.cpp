#include <iostream>
#include "ItemTracker.h"

int main() {
    ItemTracker tracker;
    tracker.loadItems("CS210_Project_Three_Input_File.txt");
    tracker.saveFrequencyData("frequency.dat");

    int choice;
    std::string item;

    do {
        std::cout << "Menu:\n";
        std::cout << "1. Find frequency of an item\n";
        std::cout << "2. Print all items with frequencies\n";
        std::cout << "3. Print histogram of items\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter item: ";
            std::cin >> item;
            std::cout << "Frequency of " << item << ": " << tracker.getItemFrequency(item) << std::endl;
            break;
        case 2:
            tracker.printAllItems();
            break;
        case 3:
            tracker.printHistogram();
            break;
        case 4:
            std::cout << "Exiting program.\n";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
