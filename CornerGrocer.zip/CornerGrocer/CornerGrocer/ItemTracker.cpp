#include "ItemTracker.h"
#include <fstream>
#include <iostream>

void ItemTracker::loadItems(const std::string& filename) {
    std::ifstream file(filename);
    std::string item;
    while (file >> item) {
        itemFrequency[item]++;
    }
    file.close();
}

int ItemTracker::getItemFrequency(const std::string& item) {
    return itemFrequency[item];
}

void ItemTracker::printAllItems() {
    for (const auto& pair : itemFrequency) {
        std::cout << pair.first << " " << pair.second << std::endl;
    }
}

void ItemTracker::printHistogram() {
    for (const auto& pair : itemFrequency) {
        std::cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
}

void ItemTracker::saveFrequencyData(const std::string& filename) {
    std::ofstream file(filename);
    for (const auto& pair : itemFrequency) {
        file << pair.first << " " << pair.second << std::endl;
    }
    file.close();
}
